﻿CREATE FUNCTION [dbo].[GetSecretKey]()

RETURNS VARCHAR(50)
AS
BEGIN
	RETURN 'Les framboises sont perchées sur le tabouret de mon grand-père'
END
